package ch5to11review;

public class Ch5to11review {

    public static void main(String[] args) {
        
        //final int size = 5;
        
        int[] my_array = new int[10];
        
        for (int i = 0; i < my_array.length; i++) {
            System.out.printf("Enter a value for my_array[%d]: ", i);
            my_array[i] = new java.util.Scanner(System.in).nextInt();
        }
        
        int counter = 0;
        
        while (counter < my_array.length) {
            System.out.printf("my_array[%d] = %d%n", counter,
                    my_array[counter++]);
        }
        
        int maximum = my_max( my_array );
        System.out.println("Maximum value is "+maximum);
        
        System.out.println( my_max(1,3,8,10,5,16,13,2) ); //16
        System.out.println( my_max(3,9,16,12,21,13) ); //21
        System.out.println( my_max());
    }

public static int my_max(int... values) {
    int max = values[0];
    for (int i = 0; i < values.length; i++)
        if (values[i] > max)
            max = values[i];
    return max;
}    
}

