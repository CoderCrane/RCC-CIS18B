/* Programmer Name: River Crane
 * Assignment Start: 3/23/20 9:15am - 10:55am, 3/24/20 9:57am - 10:58am
 * Assignment Completion: 3/24/20 10:58am
 * Total Hours for Assignment: 1 hour and 41 minutes
 * Comments: Thank you for the help with this assignment, I've enjoyed learning new programming techniques with javaFX.
 */
// TipCalculatorController.java
// Controller that handles calculateButton and tipPercentageSlider events
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;

public class TipCalculatorController 
{
   // formatters for currency and percentages
   private static final NumberFormat currency = 
      NumberFormat.getCurrencyInstance();
   private static final NumberFormat percent = 
      NumberFormat.getPercentInstance();
   
   private static final double constantTipPercentage = 0.15;
   
   private BigDecimal tipPercentage = new BigDecimal(constantTipPercentage); // 15% default
   
   // GUI controls defined in FXML and used by the controller's code
   @FXML 
   private TextField amountTextField; 

   @FXML
   private Label tipPercentageLabel; 

   @FXML
   private Slider tipPercentageSlider;

   @FXML
   private TextField tipTextField;

   @FXML
   private TextField totalTextField;
   
   @FXML
   private CheckBox CheckBoxSplitBill;
   
   @FXML
   private TextField SplitBillTotalTextField;
   
   @FXML
   private TextField NumberOfPeopleTextField;

   // calculates and displays the tip and total amounts
   @FXML
   private void calculateButtonPressed(ActionEvent event) 
           
   
   {
       
       
      try 
      {
         BigDecimal amount = new BigDecimal(amountTextField.getText());
         BigDecimal tip = amount.multiply(tipPercentage);
         BigDecimal total = amount.add(tip);

         tipTextField.setText(currency.format(tip));
         totalTextField.setText(currency.format(total));
         
         if (CheckBoxSplitBill.isSelected()) {
             if (NumberOfPeopleTextField.getText().length() > 0) {
                Integer people = new Integer(NumberOfPeopleTextField.getText());
                tip = tip.divide(BigDecimal.valueOf(people));
                SplitBillTotalTextField.setText(currency.format(tip));
             }


             
             // I want to have: total calculated currency / number of people in party = split bill total.  How do I write this in code?
             //SplitBillTotalTextField.setText( ? / ? ); cannot divide textfields or strings.  set them to values?
         }
      }
      catch (NumberFormatException ex)
      {
         amountTextField.setText("Enter amount");
         amountTextField.selectAll();
         amountTextField.requestFocus();
         
         NumberOfPeopleTextField.setText("Enter amount");
         NumberOfPeopleTextField.selectAll();
         NumberOfPeopleTextField.requestFocus();
      }
      
      
   }
   
   @FXML 
   private Button ClearButton;
   
   @FXML
   private void clearButtonPressed(ActionEvent event) {
       NumberOfPeopleTextField.setText("");
       //amount
       amountTextField.setText("");
       //tip
       tipTextField.setText("");
       //total
       totalTextField.setText("");
       //split bill total
       SplitBillTotalTextField.setText("");
       //uncheck checkbox
       CheckBoxSplitBill.setSelected(false);
       //reset slider to 15%
       tipPercentageSlider.setValue(constantTipPercentage * 100);
       
   }
   
   

   // called by FXMLLoader to initialize the controller
   public void initialize() 
   {
      // 0-4 rounds down, 5-9 rounds up 
      currency.setRoundingMode(RoundingMode.HALF_UP);
      
      // listener for changes to tipPercentageSlider's value
      tipPercentageSlider.valueProperty().addListener(
         new ChangeListener<Number>() 
         {
            @Override
            public void changed(ObservableValue<? extends Number> ov, 
               Number oldValue, Number newValue) 
            {
               tipPercentage = 
                  BigDecimal.valueOf(newValue.intValue() / 100.0);
               tipPercentageLabel.setText(percent.format(tipPercentage));
            }
         }
      );
   }
}

/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
