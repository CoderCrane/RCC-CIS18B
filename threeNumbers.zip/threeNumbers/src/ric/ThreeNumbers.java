/* Write a program to ask user for three 64 bit 
 * doubles, output the sum, average, and min/max.
 */
package ric;

import java.util.Scanner;

public class ThreeNumbers {

    public static void main(String[] args) {
        double value1 = 0, value2 = 0, value3 = 0;
        
        Scanner input = new Scanner(System.in);
        
        boolean bad_input;
        do {
            try {
        //prompt user input for 3 values
        bad_input = false;
        System.out.printf("%s", "Enter the first value: ");
        value1 = input.nextDouble();    
            }
            catch (Exception i) {
                System.out.printf("%s%n", "Incorrect value entered, please re-enter. ");
                input.nextLine();
                bad_input = true;
            }
        } while (bad_input == true); //also can do while (bad_input);
        
        do {
            try {
        //prompt user input for 3 values
        bad_input = false;
        System.out.printf("%s", "Enter the second value: ");
        value2 = input.nextDouble();    
            }
            catch (Exception i) {
                System.out.printf("%s%n", "Incorrect value entered, please re-enter. ");
                input.nextLine();
                bad_input = true;
            }
        } while (bad_input == true); //also can do while (bad_input);

        do {
            try {
        //prompt user input for 3 values
        bad_input = false;
        System.out.printf("%s", "Enter the third value: ");
        value3 = input.nextDouble();    
            }
            catch (Exception i) {
                System.out.printf("%s%n", "Incorrect value entered, please re-enter. ");
                input.nextLine();
                bad_input = true;
            }
        } while (bad_input == true); //also can do while (bad_input);
        
        //calculate sum and average
        double sum = value1 + value2 + value3;
        double average = sum / 3;
        
        double min_value = Math.min(value1, Math.min(value2, value3));
        double max_value = Math.max(value1, Math.max(value2, value3));
        
        System.out.printf("%s%2.8f%n%s%2.8f%n%s%2.8f%s%2.8f%n", "The sum is: ", sum, "The average is: ", average, "The minimum and maximum values are: ", min_value, " and ", max_value );

        
    }
    
}
