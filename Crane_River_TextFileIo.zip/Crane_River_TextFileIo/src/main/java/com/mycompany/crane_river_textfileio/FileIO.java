/* Programmer Name: River Crane
 * Assignment Start: 5/8/20 8:42am - 5/8/20 11:49am, 5/11/20 1:22pm - 3:41pm
 * Assignment Completion: 5/11/20 3:41pm
 * Total Hours for Assignment: 5 hours and 26 minutes
 * Comments: None.
 */
package com.mycompany.crane_river_textfileio;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class FileIO {
    
    public static void main(String[] args) throws IOException {
        Scanner input = new Scanner(System.in);
        
        //1. Prompt the user for the name of the text file
        System.out.printf("%s", "Enter file name: ");
        String fileWeUse = input.nextLine();
        
        File file = new File(fileWeUse);
        
        if (file.exists()) {
            System.out.printf("%n%s exists.%n", fileWeUse);
        }
        else {
            System.out.printf("%n%s%n%s%n", "File is not found or does not exist.", "Please restart and try again.");
            return;
        }
        
        //2. Opens the text file and reads in the ordered pair data
        //( which is stored in the text file in the format of:  xxx.xxxxx yyy.yyyy
        //where there is a space between the numeric values and a carriage return/line
        //feed after the last numeric value on each line).
        Scanner fileReader = new Scanner(file);
        
        //3. While looping through the read ordered pairs, have variables for the following:
        int orderedPairsProcessed = 0;
        float xValuesSum = 0;
        float yValuesSum = 0;
        float xValuesSquaredSum = 0;
        float xAndYproductsSum = 0;
            
        while (fileReader.hasNextLine()) {
            String[] arrayFromFileRead = fileReader.nextLine().split("\\s+");
            
            //1. keep count of the number of ordered pairs processed
            float xValue = Float.valueOf(arrayFromFileRead[0]);
            float yValue = Float.valueOf(arrayFromFileRead[1]);
            orderedPairsProcessed++;
            
            //2. sum of the x values
            xValuesSum += xValue;
            
            //3. sum of the y values
            yValuesSum += yValue;
            
            //4. sum of the square of the x values
            xValuesSquaredSum += xValue * xValue;
            
            //5. sum of the products of x and y
            xAndYproductsSum += xValue * yValue;
        }
        
        //4. After the ordered pairs have been read in, close the file.
        fileReader.close();
        
        //5. Compute the regression coefficients m and b for the equation
        //of the least squares line equation, where m is the slope and b is the y-intercept.
        float xValueAverage = xValuesSum / orderedPairsProcessed;
        float yValueAverage = yValuesSum / orderedPairsProcessed;
        float slopeM = (xAndYproductsSum - (xValuesSum * yValueAverage)) / (xValuesSquaredSum - (xValuesSum * xValueAverage));
        float yInterceptB = yValueAverage - (slopeM * xValueAverage);
        
        //6. The output to the terminal screen must be:
        //Equation of least squares line: y = 3.33658x + 700.82837
        System.out.printf("%n%s%.5f%s%.5f", "Equation of least square line: y = ", slopeM, "x + ", yInterceptB);
                
        //Note: When your user reruns the program and enters the data
        //file named another_test.txt, step #6 should have the output
        //to the terminal screen: Equation of least squares line: y = -0.07926x + 754.90472
    }
}
