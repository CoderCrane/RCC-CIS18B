/* Programmer Name: River Crane
 * Assignment Start: 5/29/20 9:00am - 11:15am, 5/30/20 10:10am - 1:53pm, 6/2/20 9:30am - 12:15pm, 6/3/20 10:31am - 11:44am, 6/4/20 8:15am - 11:43am, 12:50pm - 3:58pm
 * Assignment Completion: 6/4/20 3:58pm
 * Total Hours for Assignment: 16 hours and 32 minutes
 * Comments: Thank you for your continued support and teaching throughout CIS18B!  For connection to the database, the name is "history",
 * with a username and password of "history".  The DB table is named History, you can run the history_db.sql file to help set it up.
 */

package finalsinglewindow;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Display extends Application {
    
    
    @Override
    public void start(Stage stage1) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("SingleCalculatorFXML.fxml"));
        
        Scene scene = new Scene(root);
        
        stage1.setTitle("Calculator");
        stage1.setScene(scene);
        stage1.show();  
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
