package finalsinglewindow;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Queries {
    static final String DB_URL = "jdbc:derby://localhost:1527/history";
    static final String USERNAME = "history";
    static final String PASSWORD = "history";
    private static ResultSet _rs=null;
    
    //Connection to database
    Queries() {
        try 
        {
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement selectAllhistory = connection.prepareStatement("SELECT * FROM history");
            _rs = selectAllhistory.executeQuery();
        }
        catch (SQLException sqlException)
        {
           sqlException.printStackTrace();
           System.exit(1);
        }
    }
    
    //Handles adding history in tandem with FXMLcontroller's handleSaveHistoryButton.
    public void addHistory(String hs_answer)
    {
        try
        {
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement insertCar = connection.prepareStatement("INSERT INTO history (HISTORYANSWER) VALUES (?)");
            //insertCar.setInt(1, hs_id);
            insertCar.setString(1,hs_answer);
            insertCar.executeUpdate();            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
            System.exit(2);
        }
    }
    
    //Handles deleting history in tandem with FXMLcontroller's handleClearHistoryButton.
    public void deleteHistory()
    {
        try
        {
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement deleteHistory = connection.prepareStatement("DELETE FROM history");
            //deleteHistory.setInt(1, hs_id);
            deleteHistory.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
            System.exit(4);
        }
    }
    
    public ResultSet getResults()
    {
        if (_rs != null) return _rs;
        return new Queries()._rs;
    }
}
