package finalsinglewindow;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Callback;

public class FXMLController implements Serializable, Initializable {
    
    
    float data = 0f;
    int operation = -1;
    Stage stage2 = new Stage();
        
    //Advanced String usage of StringBuilder alongside getText() and setText().
    StringBuilder str0 = new StringBuilder("0");
    
    StringBuilder str1 = new StringBuilder("1");
    
    StringBuilder str2 = new StringBuilder("2");
    
    StringBuilder str3 = new StringBuilder("3");
    
    StringBuilder str4 = new StringBuilder("4");
    
    StringBuilder str5 = new StringBuilder("5");
    
    StringBuilder str6 = new StringBuilder("6");
    
    StringBuilder str7 = new StringBuilder("7");
    
    StringBuilder str8 = new StringBuilder("8");
    
    StringBuilder str9 = new StringBuilder("9");
    
    StringBuilder strClear = new StringBuilder ("");
        
    ObservableList items;
    
    @FXML private TableView tableView;
    
    @FXML private TextField hs_id, hs_answer;
    
    //Top buttons
    @FXML
    private Button clearButton, saveHistoryButton, helpButton, luckyNumberButton;
    
    //Operands buttons
    @FXML
    private Button divideButton, minusButton, equalsButton, plusButton, multiplyButton;
    
    //Label "screen"
    @FXML
    private Label display, luckyNumberDisplay;
    
    //Label "screen" for Help page instruction
    @FXML
    private TextArea instructionDisplay;
    
    //Number buttons
    @FXML
    private Button oneButton, twoButton, threeButton, fourButton, fiveButton, sixButton, sevenButton, eightButton, nineButton, zeroButton;
    
    //Clearing history tableView which works with database
    @FXML
    private Button clearHistoryButton;
    
    //Will be part of concurrency and luckyNumberDisplay
    private Service<Void> backgroundThread; 
            
    //Handle the clear button when pressed to remove numbers.
    @FXML
    void handleClearButton(ActionEvent event) {
        if(event.getSource() == clearButton) {
            display.setText(strClear.toString());
            saveHistoryButton.setDisable(true);            
        }
    }
    
    //Handle when "Save to History" button is pressed, sending the current answer to the database tableView to be saved and viewable by user.
    @FXML
    void handleSaveHistoryButton(ActionEvent event) {
        new Queries().addHistory(display.getText());
        fillTable();
        //hs_id.clear();
        hs_answer.clear();
        tableView.requestFocus();
    }
    
    //Concurrency code continues here to generate a new number for the calculator at the top!
    @FXML
    void luckyNumberButtonPressed(ActionEvent event) {
       backgroundThread = new Service<Void>() {
           @Override
           protected Task<Void> createTask() {
               return new Task<Void>() {
                   @Override
                   protected Void call() throws Exception {
                       ThreadLocalRandom random = ThreadLocalRandom.current();
		
                       int rand = random.nextInt(1, 100000);
                       instructionDisplay.setText(instructionDisplay.getText() + rand + " "); 
                       return null;
                   }  
               };
           }
           
       };
       
       backgroundThread.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
       
           @Override
           public void handle(WorkerStateEvent event) {
               luckyNumberDisplay.textProperty().unbind();
           }
       });
       
       luckyNumberDisplay.textProperty().bind(backgroundThread.messageProperty());
       
       backgroundThread.restart();
    }
    
    //Handle when "Help" button is pressed, it will read text from a .txt file name "Instruction.txt" and display it on a textArea.  This makes use of File I/O.
    @FXML
    void handleHelpButton(ActionEvent event) {
        try {
            if (!helpButton.isPressed()) {
                  File file = new File("Instruction.txt");
                Scanner scan = new Scanner(file);
                
                while(scan.hasNextLine()) {
                    instructionDisplay.setText(instructionDisplay.getText() + scan.nextLine());
                }    
                
            } 
            helpButton.setDisable(true);
        }
        catch (Exception e) {
                System.out.println(e.getMessage());
                }
    }
    
    //Handle all numbers pressed to present on the Label "screen".
    @FXML
    void processNumbers(ActionEvent event) {
        if(event.getSource() == oneButton) {
            display.setText(display.getText() + str1.toString());
        }
        else if (event.getSource() == twoButton) {
            display.setText(display.getText() + str2.toString());
        }
        else if (event.getSource() == threeButton) {
            display.setText(display.getText() + str3.toString());
        }
        else if (event.getSource() == fourButton) {
            display.setText(display.getText() + str4.toString());
        }
        else if (event.getSource() == fiveButton) {
            display.setText(display.getText() + str5.toString());
        }
        else if (event.getSource() == sixButton) {
            display.setText(display.getText() + str6.toString());
        }
        else if (event.getSource() == sevenButton) {
            display.setText(display.getText() + str7.toString());
        }
        else if (event.getSource() == eightButton) {
            display.setText(display.getText() + str8.toString());
        }
        else if (event.getSource() == nineButton) {
            display.setText(display.getText() + str9.toString());
        }
        else if (event.getSource() == zeroButton) {
            display.setText(display.getText() + str0.toString());
        }
    }
    
    //Handle all operants dealing with entered numbers.
    @FXML
    void processOperands(ActionEvent event) throws FileNotFoundException, IOException {
       if (event.getSource() == plusButton) {
           data = Float.parseFloat(display.getText());
           operation = 1; //Addition
           display.setText(strClear.toString());
       } 
       else if (event.getSource() == minusButton) {
           data = Float.parseFloat(display.getText());
           operation = 2; //Subtraction
           display.setText(strClear.toString());
       } 
       else if (event.getSource() == multiplyButton) {
           data = Float.parseFloat(display.getText());
           operation = 3; //Multiplication
           display.setText(strClear.toString());
       } 
       else if (event.getSource() == divideButton) {
           data = Float.parseFloat(display.getText());
           operation = 4; //Division
           display.setText(strClear.toString());
       } 
       else if (event.getSource() == equalsButton) {
           float secondOperand = Long.parseLong(display.getText());
           switch(operation) {
               //Addition
               case 1:
                   float answer = data + secondOperand;
                   display.setText(String.valueOf(answer));
                   //Initialize fout and out for serialization to store latest answer value.
                   FileOutputStream fout = new FileOutputStream("answers.txt");
                   ObjectOutputStream out = new ObjectOutputStream(fout);
                   out.writeObject(answer);
                   out.flush();
                   out.close();
                   saveHistoryButton.setDisable(false);
                   break;   
               //Subtraction
               case 2:
                   answer = data - secondOperand;
                   display.setText(String.valueOf(answer));
                   //Serialization to store latest answer value.
                   fout = new FileOutputStream("answers.txt");
                   out = new ObjectOutputStream(fout);
                   out.writeObject(answer);
                   out.flush();
                   out.close();
                   saveHistoryButton.setDisable(false);
                   break;
               //Multiplication
               case 3:
                   answer = data * secondOperand;
                   display.setText(String.valueOf(answer));
                   //Serialization to store latest answer value.
                   fout = new FileOutputStream("answers.txt");
                   out = new ObjectOutputStream(fout);
                   out.writeObject(answer);
                   out.flush();
                   out.close();
                   saveHistoryButton.setDisable(false);
                   break;
               //Division
               case 4:
                   try {
                       if (secondOperand != 0) {
                       answer = data / secondOperand;
                       display.setText(String.valueOf(answer));
                       //Serialization to store latest answer value.
                       fout = new FileOutputStream("answers.txt");
                       out = new ObjectOutputStream(fout);
                       out.writeObject(answer);
                       out.flush();
                       out.close();
                       saveHistoryButton.setDisable(false);
                       break;
                       }
                       else {
                           saveHistoryButton.setDisable(true);
                       }
                   }
                   catch (Exception e) { 
                       display.setText("Cannot Divide by zero. ");
                   }
           }
       } 
    }
    
    //Handles clearing the history of answers on the tableView, clearing the database.
    @FXML
    private void handleClearHistoryButton(ActionEvent event) {
        new Queries().deleteHistory();
        fillTable();
        hs_id.clear();
        hs_answer.clear();
        tableView.requestFocus();
    }
    
    //FillTable and Initialize are beneath based on CarsDatabase
        private void fillTable()
    {
        tableView.setItems(null);
        tableView.getColumns().clear();
        try 
        {
            ResultSet rs = new Queries().getResults();
            ////////////////////////////////////////////////////////////////////////////
            for(int i=0;i<rs.getMetaData().getColumnCount();i++)
            {
                TableColumn tableCol = new TableColumn(rs.getMetaData().getColumnName(i+1));        
                final int j=i;
                tableCol.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList,String>,ObservableValue<String>>(){                    
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {                                                                                              
                        return new SimpleStringProperty(param.getValue().get(j).toString());                        
                    }                    
                });
                
                tableView.getColumns().addAll(tableCol);
            }
            
            items = FXCollections.observableArrayList();
            while( rs.next() )
            {
                ObservableList<String> row = FXCollections.observableArrayList();
                for(int i=0;i<rs.getMetaData().getColumnCount();i++)
                       row.add(rs.getString(i+1));
                items.add(row);                                
            }   
            tableView.setItems(items);
        }
        catch (SQLException sqlException)
        {
           sqlException.printStackTrace();
           System.exit(1);
        }
    }    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        fillTable();
        
        tableView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observableValue, Object oldValue, Object newValue) {
                if(tableView.getSelectionModel().getSelectedItem() != null) 
                {    
                    TableView.TableViewSelectionModel selectionModel = tableView.getSelectionModel();
                }
         }
     });
    }
    
    
   
}
