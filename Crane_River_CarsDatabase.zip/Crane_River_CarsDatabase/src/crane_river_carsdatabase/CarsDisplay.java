/* Programmer Name: River Crane
 * Assignment Start: 5/24/20 6:52pm - 9:04pm, 5/26/20 10:00am - 11:15am
 * Assignment Completion: 5/26/20 11:15am
 * Total Hours for Assignment:  3 hours and 11 minutes
 * Comments: None.
 */

//CarsDisplay which displays the application

package crane_river_carsdatabase;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class CarsDisplay extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("CarsDataBaseFXML.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
