//Implement a class named CarQueries that contains the prepared statements to execute the queries

package crane_river_carsdatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CarQueries {
    static final String DB_URL = "jdbc:derby://localhost:1527/Cars";
    static final String USERNAME = "cars";
    static final String PASSWORD = "cars";
    private static ResultSet _rs=null;

    CarQueries()
    {
        try 
        {
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement selectAllcars = connection.prepareStatement("SELECT * FROM Cars");
            _rs = selectAllcars.executeQuery();
        }
        catch (SQLException sqlException)
        {
           sqlException.printStackTrace();
           System.exit(1);
        }
    }
    
    public void addCars(int cr_id, String cr_make, String cr_model, String cr_year, String cr_mileage )
    {
        try
        {
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement insertCar = connection.prepareStatement("INSERT INTO Cars (CARMAKE, CARMODEL, CARYEAR, CARMILEAGE) VALUES (?,?,?,?)");
            //insertCar.setInt(1, cr_id);
            insertCar.setString(1,cr_make);
            insertCar.setString(2,cr_model);
            insertCar.setString(3,cr_year);
            insertCar.setString(4,cr_mileage);
            insertCar.executeUpdate();            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
            System.exit(2);
        }
    }
    
    public void updateCars(int cr_id, String cr_make, String cr_model, String cr_year, String cr_mileage )
    {
        try
        {
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement updateCar = connection.prepareStatement("UPDATE Cars SET CARMAKE=?, CARMODEL=?, CARYEAR=?, CARMILEAGE=? WHERE CARID=?");
            //updateCar.setInt(1, cr_id);
            updateCar.setString(1,cr_make);
            updateCar.setString(2,cr_model);
            updateCar.setString(3,cr_year);
            updateCar.setString(4,cr_mileage);
            updateCar.setInt(5,cr_id);
            updateCar.executeUpdate();            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
            System.exit(3);
        }
    }
    
    public void deleteCars(int cr_id)
    {
        try
        {
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement deleteCar = connection.prepareStatement("DELETE FROM Cars WHERE CARID=?");
            deleteCar.setInt(1, cr_id);
            deleteCar.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
            System.exit(4);
        }
    }
    
    public ResultSet getResults()
    {
        if (_rs != null) return _rs;
        return new CarQueries()._rs;
    }
}
