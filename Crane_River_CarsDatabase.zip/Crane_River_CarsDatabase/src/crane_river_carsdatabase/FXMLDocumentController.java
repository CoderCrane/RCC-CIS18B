/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crane_river_carsdatabase;

import java.net.URL;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TableView.TableViewSelectionModel;
import javafx.scene.control.TextField;
import javafx.util.Callback;

public class FXMLDocumentController implements Initializable {
    
    @FXML private TableView tableView;
    @FXML private Button addButton;
    @FXML private TextField car_id, car_make, car_model, car_year, car_mileage;
    
    ObservableList items;
    
    @FXML
    private void handleAddButton(ActionEvent e)
    {        
        new CarQueries().addCars(Integer.parseInt(car_id.getText()), car_make.getText(),
                                        car_model.getText(), car_year.getText(), car_mileage.getText());
        fillTable();
        car_id.clear();
        car_make.clear();
        car_model.clear();
        car_year.clear();
        car_mileage.clear();
        tableView.requestFocus();
    }
    
    @FXML
    private void handleUpdateButton(ActionEvent e)
    {        
        new CarQueries().updateCars(Integer.parseInt(car_id.getText()), car_make.getText(),
                                        car_model.getText(), car_year.getText(), car_mileage.getText());
        fillTable();
        car_id.clear();
        car_make.clear();
        car_model.clear();
        car_year.clear();
        car_mileage.clear();
        tableView.requestFocus();
    }
    
    @FXML
    private void handleDeleteButton(ActionEvent e)
    {        
        new CarQueries().deleteCars(Integer.parseInt(car_id.getText()));
        fillTable();
        car_id.clear();
        car_make.clear();
        car_model.clear();
        car_year.clear();
        car_mileage.clear();
        tableView.requestFocus();
    }
    
    private void fillTable()
    {
        tableView.setItems(null);
        tableView.getColumns().clear();
        try 
        {
            ResultSet rs = new CarQueries().getResults();
            ////////////////////////////////////////////////////////////////////////////
            for(int i=0;i<rs.getMetaData().getColumnCount();i++)
            {
                TableColumn tableCol = new TableColumn(rs.getMetaData().getColumnName(i+1));        
                final int j=i;
                tableCol.setCellValueFactory(new Callback<CellDataFeatures<ObservableList,String>,ObservableValue<String>>(){                    
                    public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {                                                                                              
                        return new SimpleStringProperty(param.getValue().get(j).toString());                        
                    }                    
                });
                
                tableView.getColumns().addAll(tableCol);
            }
            
            items = FXCollections.observableArrayList();
            while( rs.next() )
            {
                ObservableList<String> row = FXCollections.observableArrayList();
                for(int i=0;i<rs.getMetaData().getColumnCount();i++)
                       row.add(rs.getString(i+1));
                items.add(row);                                
            }   
            tableView.setItems(items);
        }
        catch (SQLException sqlException)
        {
           sqlException.printStackTrace();
           System.exit(1);
        }
    }    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        fillTable();
        
        tableView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observableValue, Object oldValue, Object newValue) {
                if(tableView.getSelectionModel().getSelectedItem() != null) 
                {    
                    TableViewSelectionModel selectionModel = tableView.getSelectionModel();
                    ObservableList selectedCells = selectionModel.getSelectedCells();
                    TablePosition tablePosition = (TablePosition) selectedCells.get(0);                    
                    int val = tablePosition.getRow();
                    Object row = items.get(val);
                    String[] a = row.toString().split("[,]|[\\]]");
                    a[0]=a[0].substring(1);
                    car_id.setText(a[0].trim());
                    car_make.setText(a[1].trim());
                    car_model.setText(a[2].trim());
                    car_year.setText(a[3].trim());
                    car_mileage.setText(a[4].trim());
                }
         }
     });
    }
}
